from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.contrib.auth import login as auth_login
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from dashboard.models import Customer
import hashlib

base_url = 'users/'

# Create your views here.
def login(request):
    global base_url
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        try:
            username = User.objects.get(email=email.lower()).username
            user = authenticate(username=username, password=password)
        except:
            message = 'Email is incorrect'
            return render(request, 'login.html', {'messages': message})

        if user is not None:
            auth_login(request, user)
            return redirect("home-index")
        else:
            message = 'Password is incorrect'
            return render(request, base_url + 'login.html', {'messages': message})

    context = {
        "title" : "Login"
    }
    return render(request, "users/login.html", context)

def logout_user(request):
    logout(request)
    return redirect('users-login')

def register(request):
    global base_url
    context = {
        "title" : "Register"
    }
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        try:
            user = User.objects.get(email=email)
        except:
            user = None
        if user is not None:
            message_email = '  Email is already exist'

            context = {
                "title" : "Register",
                "messages" : message_email
            }

            return render(request, base_url + 'register.html', context)
        else:
            address = request.POST['address']
            country = request.POST['country']
            city = request.POST['city']
            postal = request.POST['postal']

            hash_string_raw = address + str(country) + str(city) + str(postal)
            result = hashlib.sha256(hash_string_raw.encode()).hexdigest()
            username = email.split("@")[0]
            try:
                user = User.objects.create_user(username=username, email=email, password=password)
                user.save()
            except:
                return JsonResponse({"message" : "error"})
            try:
                customer = Customer(address = address, country = country, city = city, postal_code = postal, user= user, hash_value = result)
                customer.save()
            except:
                return JsonResponse({"message" : "error"})
        
        return JsonResponse({"message" : "success"})
            


    return render(request, base_url + "register.html", context)