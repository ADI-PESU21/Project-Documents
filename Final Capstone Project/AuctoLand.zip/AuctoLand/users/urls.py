from django.urls import path
from .views import login, register, logout_user

urlpatterns = [    
    path('login', login, name="users-login"),
    path('register', register, name="users-register"),
    path('logout', logout_user, name="users-logout")
]